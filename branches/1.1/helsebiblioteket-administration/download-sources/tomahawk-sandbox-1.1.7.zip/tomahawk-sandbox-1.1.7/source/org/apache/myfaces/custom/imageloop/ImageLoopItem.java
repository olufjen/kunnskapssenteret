package org.apache.myfaces.custom.imageloop;

import javax.faces.component.UIGraphic;

/**
 * Image loop item. 
 * @author Felix R�thenbacher (latest modification by $Author:$)
 * @version $Revision:$ $Date:$
 */
public class ImageLoopItem extends UIGraphic {
    
    public static final String COMPONENT_TYPE = "org.apache.myfaces.ImageLoopItem";
    
}
