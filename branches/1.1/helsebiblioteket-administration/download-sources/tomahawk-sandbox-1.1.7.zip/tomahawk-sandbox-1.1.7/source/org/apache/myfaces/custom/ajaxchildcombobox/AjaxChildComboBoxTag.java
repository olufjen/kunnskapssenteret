/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */
package org.apache.myfaces.custom.ajaxchildcombobox;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.myfaces.taglib.html.ext.HtmlSelectOneMenuTag;

import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.el.MethodBinding;

/**
 * JSP tag for AjaxChildComboBox component
 * @author Sharath Reddy
 */
public class AjaxChildComboBoxTag extends HtmlSelectOneMenuTag
{
    private final static Class[] DEFAULT_SIGNATURE = new Class[]{String.class};
  
    private static Log log = LogFactory.getLog(AjaxChildComboBoxTag.class);

    private String _parentComboBox;
    private String _ajaxSelectItemsMethod;
    private String _size; //please fix this, this has to do something
    //it is referenced from the tld!!!!
    
    
    
    public String getComponentType() {
        return AjaxChildComboBox.COMPONENT_TYPE;
    }

    public String getRendererType() {
        return AjaxChildComboBox.DEFAULT_RENDERER_TYPE;
    }

    public void release() {
        super.release();
        _ajaxSelectItemsMethod = null;
        _parentComboBox = null;
    }

    protected void setProperties(UIComponent component) {

        super.setProperties(component);
        AjaxChildComboBoxTag.setAjaxSelectItemsMethodProperty(getFacesContext(),
        		component, _ajaxSelectItemsMethod);
        setStringProperty(component, "parentComboBox", _parentComboBox);
    
    }

    public static void setAjaxSelectItemsMethodProperty(FacesContext context,
                                                       UIComponent component,
                                                       String ajaxSelectItemsMethod)
    {
                            
        if (isValueReference(ajaxSelectItemsMethod))
        {
            MethodBinding mb = context.getApplication().
                createMethodBinding(ajaxSelectItemsMethod, AjaxChildComboBoxTag.DEFAULT_SIGNATURE);
            ((AjaxChildComboBox)component).setAjaxSelectItemsMethod(mb);
        }
        else
        {
            log.error("Invalid expression " + ajaxSelectItemsMethod);
        }
    }
    
    public void setAjaxSelectItemsMethod(String ajaxSelectItemsMethod)
    {
        _ajaxSelectItemsMethod = ajaxSelectItemsMethod;
    }
    
    public void setParentComboBox(String parentComboBox) 
    {
        this._parentComboBox = parentComboBox;
    }
    
    public void setSize(String size) {
    	this._size = size;
    }
}
