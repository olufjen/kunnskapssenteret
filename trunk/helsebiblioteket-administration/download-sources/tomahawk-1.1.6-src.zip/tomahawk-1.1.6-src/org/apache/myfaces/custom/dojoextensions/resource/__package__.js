dojo.kwCompoundRequire({
	browser: ["extensions.FacesIO"]
});

dojo.provide("extensions.*");
